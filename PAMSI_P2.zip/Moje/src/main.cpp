#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <sys/time.h>

#include "../headers/quickSort.hh"
#include "../headers/mergeSort.hh"
#include "../headers/bucketSort.hh"

// struktura do liczenia czasu pomiaru sortowań
struct timeval beginS, endS;

using namespace std;


// Funkcja do wyświetlania czasów sortowań
void showResults(double t1, double t2, double t3)
{
    cout << "Czas sortowania " << MAX_NUM << " elementow wynosi dla Quicksorta: " << t1 << endl;
    cout << "Czas sortowania " << MAX_NUM << " elementow wynosi dla Mergesorta: " << t2 << endl;
    cout << "Czas sortowania " << MAX_NUM << " elementow wynosi dla Bucketsorta: " << t3 << endl;

}


int main()
{
    // utrowrzenie zmiennych plikowych
    ifstream titles;
    ifstream rates;
    ofstream sorted;

    // zmienne do przechowywania tytułu i oceny dla filmu
    string lineT;
    string lineR;

    
    // otworzenie pliku z plikami, tytułami i pliku do zapisu posortowanych tytułów
    titles.open("files/titles.txt");
    rates.open("files/rates.txt");
    sorted.open("files/sorted.txt");

    // sprawdzenie czy pliki otwarto poprawnie
    if (titles.fail() || rates.fail() || sorted.fail())
    {
        cerr << "ERROR: Could not open files either titles.txt or rates.txt";
    }
    
    // utworzenie wektorów do przechowywania danych do posortowania 
    // dla różnych algorytmów
    vector<Movie> moviesQ;
    vector<Movie> moviesB;
    vector<Movie> moviesM;


    // zmienna pomocnicza do odliczania w pętli
    int limit = 0;

    // wykonuj pętlę dopóki nie skończą się dane lub wyjedziemy poza maksymalną liczbę
    // jaką chcemy posortować
    while(getline(titles, lineT) && getline(rates, lineR) && limit < MAX_NUM)
    {
        // dodaj do wektorów zmienne typu movie
        moviesQ.push_back(Movie(stof(lineR), lineT));
        moviesB.push_back(Movie(stof(lineR), lineT));
        moviesM.push_back(Movie(stof(lineR), lineT));

        limit++;
    }

    // posortowanie danych i zmierzenie czasu sortowania dla quicksort'a
    gettimeofday(&beginS, 0);
    quicksort(moviesQ, 0, MAX_NUM - 1);
    gettimeofday(&endS, 0);
    long seconds = endS.tv_sec - beginS.tv_sec;
    long microseconds = endS.tv_usec - beginS.tv_usec;
    double elapsedQuicksort = seconds + microseconds * 1e-6;

    // posortowanie danych i zmierzenie czasu sortowania dla mergesort'a
    gettimeofday(&beginS, 0);
    mergesort(moviesM, 0, MAX_NUM - 1);
    gettimeofday(&endS, 0);
    seconds = endS.tv_sec - beginS.tv_sec;
    microseconds = endS.tv_usec - beginS.tv_usec;
    double elapsedMergesort = seconds + microseconds * 1e-6;

    // posortowanie danych i zmierzenie czasu sortowania dla bucketsort'a
    gettimeofday(&beginS, 0);
    bucketsort(moviesB, 10);
    gettimeofday(&endS, 0);
    seconds = endS.tv_sec - beginS.tv_sec;
    microseconds = endS.tv_usec - beginS.tv_usec;
    double elapsedBucketsort = seconds + microseconds * 1e-6;

    
    // wyświetlenie wyników w command line
    showResults(elapsedQuicksort, elapsedMergesort, elapsedBucketsort);


    // zapis posortowanych danych do pliku 'sorted' aby sprawdzić poprawność sortowanie algorytmu
    for(int i = 0; i < MAX_NUM; i++)
    {
        sorted << moviesQ[i].name << "  ;  " << fixed << setprecision(1) << moviesQ[i].rate << endl;
        // sorted << moviesM[i].name << "  ;  " << fixed << setprecision(1) << moviesM[i].rate << endl;
        // sorted << moviesB[i].name << "  ;  " << fixed << setprecision(1) << moviesB[i].rate << endl;

    }

    // zamknięcie plików
    titles.close();
    rates.close();
    sorted.close();



    return 0;
}