import re

# Otworzenie plików do zapisania tytułów, ocen, a także wszystkiego naraz
sortedFile = open('../files/ordered.txt', 'w')
titles = open('../files/titles.txt', 'w')
rates = open('../files/rates.txt', 'w')

# Otworzenie pliku z bazą tytułów i ocen
with open('../files/set.txt', 'r', errors='ignore') as file:
    # iterowanie przez wszystkie linie w pliku
    for line in file.readlines():
        # użycie regex expression aby wydobyć tytuł i ocenę z danej linii
        sort = re.compile(r'\d+,(.*),(\d{1,2}\.\d)')
        # przeszukanie schematu w lini 
        goal = sort.search(line)
        # jeśli schemat regex występuje, to zapisz tytuł i ocenę w odpowiednich plikach
        if goal is not None:
            sortedLine = goal.group(1) + ' ; ' + goal.group(2) + '\n'
            sortedFile.write(sortedLine)
            titles.write(goal.group(1) + '\n')
            rates.write(goal.group(2) + '\n')


file.close()
sortedFile.close()
titles.close()
rates.close()