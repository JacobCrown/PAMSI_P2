#ifndef MOVIE_HH
#define MOVIE_HH


#include <iostream>
#include <string>


// tutaj definiujemy liczbę elementów do posortowania
#define MAX_NUM 962766


/********************************
 ******** Struktura MOVIE *******
 * służy do przechowywanie tytu-*
 *     łu filmu i jego oceny    *
 * *****************************/


struct Movie{

    float rate;                             // przechowywanie oceny filmu
    std::string name;                       // przechowywanie nazwy filmu
    Movie(float rev, std::string name){this->rate = rev; this->name = name;}    // konstruktor
    Movie(){rate = 0; name = "";}               // konstruktor bezparametryczny
    Movie & operator=(const Movie & temp);      // deklaracja przeciążenia operatora =
    bool operator<(Movie& two ){return this->getReviev() < two.getReviev();} // przeciążenie operatora <


public:

    float& getReviev(){ return rate;}


};

// przeciążenie operatora << do łatwiejszego operowania na zmiennej Movie
std::ostream& operator<<(std::ostream& stream, Movie m)
{
    stream << m.name << " ; " << std::to_string(m.rate) << std::endl;
    return stream;
}

// przeciążenie operatora = aby móc przypisywać elementy typu Movie
Movie & Movie::operator=(const Movie & temp)
{
    rate = temp.rate;
    name = temp.name;

    return *this;
}




#endif