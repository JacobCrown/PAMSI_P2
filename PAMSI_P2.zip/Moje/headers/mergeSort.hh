#include <iostream>
#include <vector>

#include "movie.hh"






// scalenie podtablic
void merge(std::vector<Movie> &tab, int left, int mid, int right) 
{
	int i = 0;
  int j = mid + 1;
  int p = left;
  int m = j - left;

  Movie *help;

  // zmienna pomocnicza
  help = new Movie[right - left + 1];
 
  //kopiujemy lewą i prawą część tablicy do tablicy pomocniczej
  for(int i = 0; i <= (right - left); i++, p++) 
    help[i] = tab[p];  

  
  //scalenie dwóch podtablic pomocniczych i zapisanie ich 
  //we własciwej tablicy
  for(int k = left; k <= right; k++) 
  {
    if(i<=(mid - left))
      if(m <= (right - left))
          if(help[m].getReviev()<help[i].getReviev())
              tab[k] = help[m++];
          else
              tab[k] = help[i++];
      else
          tab[k] = help[i++];
    else
        tab[k] = help[m++];
  }
  // zwolnienie pamięci
  delete [] help;
}



void mergesort(std::vector<Movie> &tab, int left, int right)
{
	//gdy mamy jeden element, to jest on już posortowany
	if(right <= left) return; 
	
	//znajdujemy mid podtablicy
	int mid = (right  +left)/2;
	
	//dzielimy tablice na częsć lewą i prawa
	mergesort(tab, left, mid); 
	mergesort(tab, mid+1, right);
	
	//scalamy dwie już posortowane tablice
	merge(tab, left, mid, right);
}