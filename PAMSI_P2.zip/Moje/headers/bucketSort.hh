#include<iostream>
#include<vector>
#include<algorithm>

#include "movie.hh"



void bucketsort(std::vector<Movie> &tab, int size) {

    // utworzenie pojemników na dane
    std::vector<Movie> * bucket = new std::vector<Movie>[size];


    for(int i = 0; i<MAX_NUM; i++)  
    {          
        // wkładanie elementów do odpowiednich pojemników
        bucket[int(tab[i].getReviev()) - 1].push_back(tab[i]);

    }
    // zmienna pomocnicza
    int index = 0;
    // zdejmowanie elementów z pojemników
    for(int i = 0; i<size; i++) {
        for(unsigned int j = 0; j<bucket[i].size(); j++)
        {
            // zdejmowanie elementów z kolejno 1 pojemnika, potem 2 itd.
            tab[index++] = (bucket[i][j]);
        }
    }
    // zwolnienie pamięci
    delete [] bucket;

}