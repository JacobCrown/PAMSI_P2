#include <iostream>
#include <vector>

#include "movie.hh"



void quicksort(std::vector<Movie> &tab, int left, int right) 
{ 
    // pivot będzie środkowym elementem z tablicy
    float v=tab[(left+right)/2].getReviev(); 
    int i=left; 
    int j = right;

    // zmienna pomocnicza przy podmianie elementów
    Movie help; 

    do{ 
        // znajdź element większy od pivota po lewej stronie
        while (tab[i].getReviev()<v) i++; 
        // znajdź element mniejszy od pivota po prawej stronie
        while (tab[j].getReviev()>v) j--; 
        if (i<=j){ 
            // zamień elementy miejscami
            help=tab[i]; 
            tab[i]=tab[j]; 
            tab[j]=help; 
            i++; 
            j--; 
        } 
    } while (i<=j); 
    // wykonaj rekurencję
    if (j>left) quicksort(tab,left, j); 
    if (i<right) quicksort(tab, i, right);
    
}